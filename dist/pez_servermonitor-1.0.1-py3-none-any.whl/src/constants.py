import os

GET_WAN_IP = "https://api.ipify.org/"
ROOT_DIR = os.path.realpath(os.path.join(os.path.dirname(__file__), ".."))
